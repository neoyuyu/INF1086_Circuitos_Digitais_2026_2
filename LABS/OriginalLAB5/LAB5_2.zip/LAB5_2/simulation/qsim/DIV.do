onerror {quit -f}
vlib work
vlog -work work DIV.vo
vlog -work work DIV.vt
vsim -novopt -c -t 1ps -L cycloneiv_ver -L altera_ver -L altera_mf_ver -L 220model_ver -L sgate work.DIV24_vlg_vec_tst
vcd file -direction DIV.msim.vcd
vcd add -internal DIV24_vlg_vec_tst/*
vcd add -internal DIV24_vlg_vec_tst/i1/*
add wave /*
run -all
