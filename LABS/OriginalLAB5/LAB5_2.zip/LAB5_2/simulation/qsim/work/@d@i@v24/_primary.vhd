library verilog;
use verilog.vl_types.all;
entity DIV24 is
    port(
        q               : out    vl_logic;
        rst             : in     vl_logic;
        clk             : in     vl_logic
    );
end DIV24;
