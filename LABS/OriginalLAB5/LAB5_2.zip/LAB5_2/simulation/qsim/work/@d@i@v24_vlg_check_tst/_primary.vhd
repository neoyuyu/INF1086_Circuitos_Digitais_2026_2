library verilog;
use verilog.vl_types.all;
entity DIV24_vlg_check_tst is
    port(
        q               : in     vl_logic;
        sampler_rx      : in     vl_logic
    );
end DIV24_vlg_check_tst;
