library verilog;
use verilog.vl_types.all;
entity DIV24_vlg_vec_tst is
end DIV24_vlg_vec_tst;
