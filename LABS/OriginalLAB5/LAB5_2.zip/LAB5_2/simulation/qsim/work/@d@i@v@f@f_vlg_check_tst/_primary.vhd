library verilog;
use verilog.vl_types.all;
entity DIVFF_vlg_check_tst is
    port(
        Q               : in     vl_logic;
        sampler_rx      : in     vl_logic
    );
end DIVFF_vlg_check_tst;
