library verilog;
use verilog.vl_types.all;
entity DIVFF_vlg_vec_tst is
end DIVFF_vlg_vec_tst;
